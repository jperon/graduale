Documents gabc
==============

Musite génère automatiquement un aperçu pdf et un fichier midi de chaque document gabc, afin de permettre une relecture facile des partitions.

En outre, il permet d'exporter ces documents dans trois formats différents :

- en pdf : l'utilisateur peut personnaliser les réglages de mise en page ;
- en midi : l'utilisateur peut définir le *tempo* et la *transposition* ;
- en lilypond : la mélodie est traduite en partition classique, ce qui peut notamment intéresser un organiste accompagnateur.